import React from 'react';
import AppContainer from './src/routes/index';

const App = () => (
  <AppContainer />
);

export default App;

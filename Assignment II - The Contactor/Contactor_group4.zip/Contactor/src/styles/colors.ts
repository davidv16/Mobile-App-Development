export const periwinkle = '#CAE5FF';
export const freshAir = '#ACEDFF';
export const jordyBlue = '#89BBFE';
export const silverLakeBlue = '#6F8AB7';
export const graniteGray = '#615D6C';
export const darkerBlue = '#42638E';

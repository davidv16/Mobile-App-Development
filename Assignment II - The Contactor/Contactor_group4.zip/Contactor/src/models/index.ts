export default interface IContact {
    id: string;
    name: string;
    phoneNumber: string;
    image: string;
}
